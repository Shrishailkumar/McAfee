package mcafee.android.com.shrishailkumarmcafeetask.model;

import java.util.Scanner;

/**
 * Created by Shrishailkumar Maddaraki on 11/25/2019.
 */
public class ThreadTaskMcFee {

    public static void main(String a[]){
        String inputStr = "Sunset is the time of day when our sky meets the solar winds";
        int threadCount = 5;
        Thread threads;
        createThreads();

    }

    private static void createThreads() {

    }
}
